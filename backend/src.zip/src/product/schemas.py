from pydantic import BaseModel
from datetime import datetime
from typing import Optional

# Product schema
class ProductBase(BaseModel):
    name: str
    image: str    
    price: float
    discount_price: float
    quantity: int
    description: str
    supplier: str
    
        
class ProductCreate(ProductBase):
    created_at: datetime
    updated_at: datetime
    
        
class ProductUpdate(ProductBase):
    name: Optional[str]
    image: Optional[str]    
    price: Optional[float]
    discount_price: Optional[float]
    quantity: Optional[int]
    description: Optional[str]
    supplier: Optional[str]
    updated_at: datetime
    
        
        
# Product group schema
class ProductGroup(BaseModel):
    name: str
    
        
class ProductGroupCreate(ProductGroup):
    created_at: datetime
    
        
class ProductGroupUpdate(BaseModel):
    name: Optional[str]
    updated_at: datetime
    

# Product category schema
class ProductCategory(BaseModel):
    name: str
    
        
class ProductCategoryCreate(ProductCategory):
    group_id: int
    created_at: datetime
    
    
class ProductCategoryUpdate(ProductCategory):
    name: Optional[str]
    updated_at: datetime
    

class ProductSearch(BaseModel):
    group_name: Optional[str] = None
    category_name: Optional[str] = None
    product_name: Optional[str] = None
    supplier: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    discount_price: Optional[bool] = None
    quantity: Optional[bool] = None
    