from pydantic import BaseModel
from datetime import datetime
from decimal import Decimal
from typing import Optional

# Order schema 
class OrderBase(BaseModel):
    id: int
    user_id: int
    total_amount: Decimal
    
class OrderCreate(OrderBase):
    user_id: int
    total_amount: Decimal
    order_date: datetime
    
class OrderUpdate(OrderBase):
    user_id: Optional[int]
    total_amount: Optional[Decimal]
    updated_at: datetime
    
# Order detail schema 
class OrderDetail(BaseModel):
    id: int
    order_id: int
    product_id: int
    quantity: int
    unit_price: Decimal
    
class OrderDetailCreate(BaseModel):
    order_id: int
    product_id: int
    quantity: int
    unit_price: Decimal
    created_at: datetime
    
class OrderDetailUpdate(BaseModel):
    product_id: Optional[int]
    quantity: Optional[int]
    unit_price: Optional[Decimal]
    updated_at: datetime
    
